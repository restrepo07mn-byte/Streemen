# STREEMEN — plataforma completa base

Incluye backend Node/Express + SQLite, registro/login, roles, catálogo, lista, planes demo, panel admin y carga de archivos.

## Ejecutar
1. Instala Node.js 20+.
2. En esta carpeta ejecuta `npm install`.
3. Ejecuta `npm start`.
4. Abre `http://localhost:3000`.

Admin demo: `admin@streemen.com` / `admin123`.

## Para producción
- Cambiar JWT_SECRET por un secreto seguro.
- PostgreSQL/Supabase o equivalente gestionado.
- Almacenamiento de video + CDN y HLS/DASH.
- Pasarela de pagos y webhooks reales.
- HTTPS, rate limiting, backups, logs, observabilidad y recuperación de cuenta.
- App móvil/TV y publicación en sus respectivas tiendas.
- Contenido propio o licenciado y contratos de distribución.
